package exercise2;



public class Duration {

	private String  start;
	private String end;
	public Duration() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getStart() {
		return start;
	}
	public void setStart(String start) {
		this.start = start;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public Duration(String start, String end) {
		super();
		this.start = start;
		this.end = end;
	}
	
	
	
}

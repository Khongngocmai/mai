package fa.training.dao;

public class EmployeeDao {

}
